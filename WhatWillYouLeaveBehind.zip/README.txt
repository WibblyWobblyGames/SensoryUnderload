Sensory Underload Design Challenge

Game: What Will You Leave Behind?

Setup:

1. Open Folder WhatWillYouLeaveBehind
2. Double click on SensoryUnderload.exe
